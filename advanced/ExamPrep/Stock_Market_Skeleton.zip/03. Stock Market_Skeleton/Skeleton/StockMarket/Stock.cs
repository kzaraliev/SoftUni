﻿namespace StockMarket
{
    public class Stock
    {

    }
}
