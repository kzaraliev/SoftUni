﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person persone = new Person();

            persone.Name = "Peur";
            persone.Age = 19;

        }
    }
}
