﻿using System;
using System.Collections.Generic;

namespace _5.GenericCountMethodStrings
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<Box<string>> boxes = new List<Box<string>>();
            for (int i = 0; i < n; i++)
            {
                string text = Console.ReadLine();
                Box<string> box = new Box<string>(text);
                boxes.Add(box);
            }

            string elementToCompare = Console.ReadLine();

            Console.WriteLine(boxes[0].Compare(elementToCompare, boxes));
            
        }
    }
}
