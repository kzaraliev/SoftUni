using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Numerics;

namespace FootballTeam.Tests
{
    public class Tests
    {
        //test props
        [Test]
        public void NameCantBeNull()
        {
            FootballTeam football;
            Assert.Throws<ArgumentException>(() => football = new FootballTeam(null, 20));
        }

        [Test]
        public void MinCapacity15()
        {
            FootballTeam football;
            Assert.Throws<ArgumentException>(() => football = new FootballTeam("Orlite", 4));
        }

        [Test]
        public void CountRiseWhenAddPlayer()
        {
            FootballTeam footballTeam = new FootballTeam("Orli", 20);
            FootballPlayer football = new FootballPlayer("Pepi", 3, "Midfielder");
            footballTeam.AddNewPlayer(football);

            List<FootballPlayer> players = new List<FootballPlayer>();
            players.Add(football);

            Assert.AreEqual(players.Count, footballTeam.Players.Count);
        }

        //Add new player
        [Test]
        public void AddWork()
        {
            FootballTeam footballTeam = new FootballTeam("Orli", 20);
            FootballPlayer football = new FootballPlayer("Pepi", 3, "Midfielder");

            Assert.AreEqual("Added player Pepi in position Midfielder with number 3",
                footballTeam.AddNewPlayer(football));
        }

        [Test]
        public void CantOverLoadTheTeam()
        {
            FootballTeam footballTeam = new FootballTeam("Orli", 15);

            for (int i = 0; i < 15; i++)
            {
                FootballPlayer football = new FootballPlayer("Pepi", 3, "Midfielder");
                footballTeam.AddNewPlayer(football);
            }

            FootballPlayer palPlayer = new FootballPlayer("GHoo", 5, "Midfielder");

            Assert.AreEqual("No more positions available!", footballTeam.AddNewPlayer(palPlayer));
        }

        [Test]
        public void CantAddPlayerWithWrongName()
        {
            FootballTeam footballTeam = new FootballTeam("Orli", 15);
            FootballPlayer palPlayer;

            Assert.Throws<ArgumentException>(() => palPlayer = new FootballPlayer("", 5, "Midfielder"));
        }

        [Test]
        public void CantAddPlayerWithWrongNumber()
        {
            FootballTeam footballTeam = new FootballTeam("Orli", 15);
            FootballPlayer palPlayer;

            Assert.Throws<ArgumentException>(() => palPlayer = new FootballPlayer("GHoo", -5, "Midfielder"));
        }

    //Pick player
        [Test]
        public void ReturnExistingPlayer()
        {
            FootballTeam footballTeam = new FootballTeam("Orli", 15);
            FootballPlayer football = new FootballPlayer("Pepi", 3, "Midfielder");
            footballTeam.AddNewPlayer(football);

            Assert.AreEqual(football, footballTeam.PickPlayer("Pepi"));
        }

        [Test]
        public void ReturnNullIfDoesntExist()
        {
            FootballTeam footballTeam = new FootballTeam("Orli", 15);
            Assert.AreEqual(null, footballTeam.PickPlayer("Pepi"));
        }

        //Player score
        [Test]
        public void ScoreMethodWork()
        {
            FootballTeam footballTeam = new FootballTeam("Orli", 15);
            FootballPlayer football = new FootballPlayer("Pepi", 3, "Midfielder");
            footballTeam.AddNewPlayer(football);

            Assert.AreEqual($"Pepi scored and now has 1 for this season!", footballTeam.PlayerScore(3));
            Assert.AreEqual(1,football.ScoredGoals);
        }

        [Test]
        public void UnexistingPlayerToScore()
        {
            FootballTeam footballTeam = new FootballTeam("Orli", 15);

            Assert.Throws<NullReferenceException>(() => footballTeam.PlayerScore(3));
        }
    }
}