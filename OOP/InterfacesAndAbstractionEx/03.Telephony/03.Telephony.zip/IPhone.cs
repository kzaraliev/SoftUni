﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Telephony
{
    public interface IPhone
    {
        public void Calling(string number);
    }
}
