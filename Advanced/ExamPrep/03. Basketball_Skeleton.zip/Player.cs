﻿using System;

namespace Basketball
{
    public class Player
    {
    }
}
