﻿namespace ExtractBytes
{
    class Program
    {
        static void Main(string[] args)
        {
            ExtractBytes.ExtractBytesFromBinaryFile("C:\\Users\\sasADASDaAS\\Desktop\\05Extractbytes\\example.png", "C:\\Users\\sasADASDaAS\\Desktop\\05Extractbytes\\bytes.txt", "C:\\Users\\sasADASDaAS\\Desktop\\05Extractbytes\\output.txt");
        }
    }
}