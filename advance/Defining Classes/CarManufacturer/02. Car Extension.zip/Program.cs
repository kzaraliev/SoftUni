﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new Car()
            {
                Make = "BMW",
                Model = "X5",
                Year = 2006,
                FuelConsumption = 0.3,
                FuelQuantity = 100
            };

            while (true)
            {
                Console.WriteLine($"Distance?");
                car.Drive(int.Parse(Console.ReadLine()));
                Console.WriteLine($"Left fuel: {car.FuelQuantity}");
            }
        }
    }
}
